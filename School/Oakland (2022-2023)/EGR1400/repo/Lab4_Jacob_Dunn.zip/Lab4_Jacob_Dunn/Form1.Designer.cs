﻿namespace Lab4_Jacob_Dunn
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnRoll = new System.Windows.Forms.Button();
            this.pic11 = new System.Windows.Forms.PictureBox();
            this.pic12 = new System.Windows.Forms.PictureBox();
            this.pic21 = new System.Windows.Forms.PictureBox();
            this.pic13 = new System.Windows.Forms.PictureBox();
            this.pic14 = new System.Windows.Forms.PictureBox();
            this.pic15 = new System.Windows.Forms.PictureBox();
            this.pic16 = new System.Windows.Forms.PictureBox();
            this.pic22 = new System.Windows.Forms.PictureBox();
            this.pic23 = new System.Windows.Forms.PictureBox();
            this.pic24 = new System.Windows.Forms.PictureBox();
            this.pic25 = new System.Windows.Forms.PictureBox();
            this.pic26 = new System.Windows.Forms.PictureBox();
            this.picWPuck9 = new System.Windows.Forms.PictureBox();
            this.picWPuck4 = new System.Windows.Forms.PictureBox();
            this.picWPuck5 = new System.Windows.Forms.PictureBox();
            this.picWPuck6 = new System.Windows.Forms.PictureBox();
            this.picWPuck8 = new System.Windows.Forms.PictureBox();
            this.picWPuck10 = new System.Windows.Forms.PictureBox();
            this.picBPuck = new System.Windows.Forms.PictureBox();
            this.txtStats = new System.Windows.Forms.TextBox();
            this.lblStats = new System.Windows.Forms.Label();
            this.lblDie1 = new System.Windows.Forms.Label();
            this.lblDie2 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblPoint = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.txtDie1 = new System.Windows.Forms.TextBox();
            this.txtDie2 = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtPoint = new System.Windows.Forms.TextBox();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pic11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBPuck)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRoll
            // 
            this.btnRoll.Location = new System.Drawing.Point(2, 460);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(146, 61);
            this.btnRoll.TabIndex = 0;
            this.btnRoll.Text = "Roll";
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // pic11
            // 
            this.pic11.Image = ((System.Drawing.Image)(resources.GetObject("pic11.Image")));
            this.pic11.Location = new System.Drawing.Point(111, 404);
            this.pic11.Name = "pic11";
            this.pic11.Size = new System.Drawing.Size(50, 50);
            this.pic11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic11.TabIndex = 1;
            this.pic11.TabStop = false;
            this.pic11.Visible = false;
            // 
            // pic12
            // 
            this.pic12.Image = ((System.Drawing.Image)(resources.GetObject("pic12.Image")));
            this.pic12.Location = new System.Drawing.Point(108, 404);
            this.pic12.Name = "pic12";
            this.pic12.Size = new System.Drawing.Size(53, 50);
            this.pic12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic12.TabIndex = 2;
            this.pic12.TabStop = false;
            this.pic12.Visible = false;
            // pic21
            // 
            this.pic21.Image = ((System.Drawing.Image)(resources.GetObject("pic21.Image")));
            this.pic21.Location = new System.Drawing.Point(170, 460);
            this.pic21.Name = "pic21";
            this.pic21.Size = new System.Drawing.Size(50, 50);
            this.pic21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic21.TabIndex = 3;
            this.pic21.TabStop = false;
            this.pic21.Visible = false;
            // 
            // pic13
            // 
            this.pic13.Image = ((System.Drawing.Image)(resources.GetObject("pic13.Image")));
            this.pic13.Location = new System.Drawing.Point(108, 404);
            this.pic13.Name = "pic13";
            this.pic13.Size = new System.Drawing.Size(52, 50);
            this.pic13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic13.TabIndex = 4;
            this.pic13.TabStop = false;
            this.pic13.Visible = false;
            // 
            // pic14
            // 
            this.pic14.Image = ((System.Drawing.Image)(resources.GetObject("pic14.Image")));
            this.pic14.Location = new System.Drawing.Point(107, 404);
            this.pic14.Name = "pic14";
            this.pic14.Size = new System.Drawing.Size(53, 50);
            this.pic14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic14.TabIndex = 5;
            this.pic14.TabStop = false;
            this.pic14.Visible = false;
            // 
            // pic15
            // 
            this.pic15.Image = ((System.Drawing.Image)(resources.GetObject("pic15.Image")));
            this.pic15.Location = new System.Drawing.Point(108, 404);
            this.pic15.Name = "pic15";
            this.pic15.Size = new System.Drawing.Size(52, 50);
            this.pic15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic15.TabIndex = 6;
            this.pic15.TabStop = false;
            this.pic15.Visible = false;
            // 
            // pic16
            // 
            this.pic16.Image = ((System.Drawing.Image)(resources.GetObject("pic16.Image")));
            this.pic16.Location = new System.Drawing.Point(108, 404);
            this.pic16.Name = "pic16";
            this.pic16.Size = new System.Drawing.Size(53, 50);
            this.pic16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic16.TabIndex = 7;
            this.pic16.TabStop = false;
            this.pic16.Visible = false;
            // 
            // pic22
            // 
            this.pic22.Image = ((System.Drawing.Image)(resources.GetObject("pic22.Image")));
            this.pic22.Location = new System.Drawing.Point(167, 460);
            this.pic22.Name = "pic22";
            this.pic22.Size = new System.Drawing.Size(53, 50);
            this.pic22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic22.TabIndex = 8;
            this.pic22.TabStop = false;
            this.pic22.Visible = false;
            // 
            // pic23
            // 
            this.pic23.Image = ((System.Drawing.Image)(resources.GetObject("pic23.Image")));
            this.pic23.Location = new System.Drawing.Point(167, 460);
            this.pic23.Name = "pic23";
            this.pic23.Size = new System.Drawing.Size(52, 50);
            this.pic23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic23.TabIndex = 9;
            this.pic23.TabStop = false;
            this.pic23.Visible = false;
            // 
            // pic24
            // 
            this.pic24.Image = ((System.Drawing.Image)(resources.GetObject("pic24.Image")));
            this.pic24.Location = new System.Drawing.Point(167, 460);
            this.pic24.Name = "pic24";
            this.pic24.Size = new System.Drawing.Size(53, 50);
            this.pic24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic24.TabIndex = 10;
            this.pic24.TabStop = false;
            this.pic24.Visible = false;
            // 
            // pic25
            // 
            this.pic25.Image = ((System.Drawing.Image)(resources.GetObject("pic25.Image")));
            this.pic25.Location = new System.Drawing.Point(168, 460);
            this.pic25.Name = "pic25";
            this.pic25.Size = new System.Drawing.Size(52, 50);
            this.pic25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic25.TabIndex = 11;
            this.pic25.TabStop = false;
            this.pic25.Visible = false;
            // 
            // pic26
            // 
            this.pic26.Image = ((System.Drawing.Image)(resources.GetObject("pic26.Image")));
            this.pic26.Location = new System.Drawing.Point(167, 460);
            this.pic26.Name = "pic26";
            this.pic26.Size = new System.Drawing.Size(53, 50);
            this.pic26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic26.TabIndex = 12;
            this.pic26.TabStop = false;
            this.pic26.Visible = false;
            // 
            // picWPuck9
            // 
            this.picWPuck9.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.picWPuck9.Image = ((System.Drawing.Image)(resources.GetObject("picWPuck9.Image")));
            this.picWPuck9.Location = new System.Drawing.Point(406, 70);
            this.picWPuck9.Name = "picWPuck9";
            this.picWPuck9.Size = new System.Drawing.Size(41, 38);
            this.picWPuck9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picWPuck9.TabIndex = 13;
            this.picWPuck9.TabStop = false;
            this.picWPuck9.Visible = false;
            // 
            // picWPuck4
            // 
            this.picWPuck4.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.picWPuck4.Image = ((System.Drawing.Image)(resources.GetObject("picWPuck4.Image")));
            this.picWPuck4.Location = new System.Drawing.Point(154, 70);
            this.picWPuck4.Name = "picWPuck4";
            this.picWPuck4.Size = new System.Drawing.Size(41, 38);
            this.picWPuck4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picWPuck4.TabIndex = 14;
            this.picWPuck4.TabStop = false;
            this.picWPuck4.Visible = false;
            // 
            // picWPuck5
            // 
            this.picWPuck5.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.picWPuck5.Image = ((System.Drawing.Image)(resources.GetObject("picWPuck5.Image")));
            this.picWPuck5.Location = new System.Drawing.Point(217, 70);
            this.picWPuck5.Name = "picWPuck5";
            this.picWPuck5.Size = new System.Drawing.Size(41, 38);
            this.picWPuck5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picWPuck5.TabIndex = 15;
            this.picWPuck5.TabStop = false;
            this.picWPuck5.Visible = false;
            // 
            // picWPuck6
            // 
            this.picWPuck6.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.picWPuck6.Image = ((System.Drawing.Image)(resources.GetObject("picWPuck6.Image")));
            this.picWPuck6.Location = new System.Drawing.Point(282, 70);
            this.picWPuck6.Name = "picWPuck6";
            this.picWPuck6.Size = new System.Drawing.Size(41, 38);
            this.picWPuck6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picWPuck6.TabIndex = 16;
            this.picWPuck6.TabStop = false;
            this.picWPuck6.Visible = false;
            // 
            // picWPuck8
            // 
            this.picWPuck8.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.picWPuck8.Image = ((System.Drawing.Image)(resources.GetObject("picWPuck8.Image")));
            this.picWPuck8.Location = new System.Drawing.Point(345, 70);
            this.picWPuck8.Name = "picWPuck8";
            this.picWPuck8.Size = new System.Drawing.Size(41, 38);
            this.picWPuck8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picWPuck8.TabIndex = 17;
            this.picWPuck8.TabStop = false;
            this.picWPuck8.Visible = false;
            // 
            // picWPuck10
            // 
            this.picWPuck10.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.picWPuck10.Image = ((System.Drawing.Image)(resources.GetObject("picWPuck10.Image")));
            this.picWPuck10.Location = new System.Drawing.Point(472, 70);
            this.picWPuck10.Name = "picWPuck10";
            this.picWPuck10.Size = new System.Drawing.Size(41, 38);
            this.picWPuck10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picWPuck10.TabIndex = 18;
            this.picWPuck10.TabStop = false;
            this.picWPuck10.Visible = false;
            // 
            // picBPuck
            // 
            this.picBPuck.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.picBPuck.Image = ((System.Drawing.Image)(resources.GetObject("picBPuck.Image")));
            this.picBPuck.Location = new System.Drawing.Point(539, 48);
            this.picBPuck.Name = "picBPuck";
            this.picBPuck.Size = new System.Drawing.Size(41, 38);
            this.picBPuck.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picBPuck.TabIndex = 19;
            this.picBPuck.TabStop = false;
            // 
            // txtStats
            // 
            this.txtStats.BackColor = System.Drawing.Color.Black;
            this.txtStats.Location = new System.Drawing.Point(552, 92);
            this.txtStats.Multiline = true;
            this.txtStats.Name = "txtStats";
            this.txtStats.Size = new System.Drawing.Size(220, 324);
            this.txtStats.TabIndex = 20;
            // 
            // lblStats
            // 
            this.lblStats.AutoSize = true;
            this.lblStats.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblStats.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblStats.Location = new System.Drawing.Point(563, 106);
            this.lblStats.Name = "lblStats";
            this.lblStats.Size = new System.Drawing.Size(51, 20);
            this.lblStats.TabIndex = 21;
            this.lblStats.Text = "Stats:";
            // 
            // lblDie1
            // 
            this.lblDie1.AutoSize = true;
            this.lblDie1.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblDie1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblDie1.Location = new System.Drawing.Point(563, 157);
            this.lblDie1.Name = "lblDie1";
            this.lblDie1.Size = new System.Drawing.Size(50, 20);
            this.lblDie1.TabIndex = 22;
            this.lblDie1.Text = "Die 1:";
            // 
            // lblDie2
            // 
            this.lblDie2.AutoSize = true;
            this.lblDie2.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblDie2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblDie2.Location = new System.Drawing.Point(563, 190);
            this.lblDie2.Name = "lblDie2";
            this.lblDie2.Size = new System.Drawing.Size(50, 20);
            this.lblDie2.TabIndex = 23;
            this.lblDie2.Text = "Die 2:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblTotal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTotal.Location = new System.Drawing.Point(563, 225);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(48, 20);
            this.lblTotal.TabIndex = 24;
            this.lblTotal.Text = "Total:";
            // 
            // lblPoint
            // 
            this.lblPoint.AutoSize = true;
            this.lblPoint.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblPoint.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblPoint.Location = new System.Drawing.Point(563, 315);
            this.lblPoint.Name = "lblPoint";
            this.lblPoint.Size = new System.Drawing.Size(53, 20);
            this.lblPoint.TabIndex = 25;
            this.lblPoint.Text = "Point: ";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.BackColor = System.Drawing.SystemColors.InfoText;
            this.lblScore.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblScore.Location = new System.Drawing.Point(563, 365);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(55, 20);
            this.lblScore.TabIndex = 26;
            this.lblScore.Text = "Score:";
            // 
            // txtDie1
            // 
            this.txtDie1.BackColor = System.Drawing.Color.Black;
            this.txtDie1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtDie1.Location = new System.Drawing.Point(619, 154);
            this.txtDie1.Name = "txtDie1";
            this.txtDie1.Size = new System.Drawing.Size(39, 26);
            this.txtDie1.TabIndex = 27;
            // 
            // txtDie2
            // 
            this.txtDie2.BackColor = System.Drawing.Color.Black;
            this.txtDie2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtDie2.Location = new System.Drawing.Point(619, 190);
            this.txtDie2.Name = "txtDie2";
            this.txtDie2.Size = new System.Drawing.Size(39, 26);
            this.txtDie2.TabIndex = 28;
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.Black;
            this.txtTotal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTotal.Location = new System.Drawing.Point(619, 225);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(39, 26);
            this.txtTotal.TabIndex = 29;
            // 
            // txtPoint
            // 
            this.txtPoint.BackColor = System.Drawing.Color.Black;
            this.txtPoint.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtPoint.Location = new System.Drawing.Point(619, 312);
            this.txtPoint.Name = "txtPoint";
            this.txtPoint.Size = new System.Drawing.Size(39, 26);
            this.txtPoint.TabIndex = 30;
            // 
            // txtScore
            // 
            this.txtScore.BackColor = System.Drawing.Color.Black;
            this.txtScore.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtScore.Location = new System.Drawing.Point(619, 365);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(39, 26);
            this.txtScore.TabIndex = 31;
            // 
            // txtOutput
            // 
            this.txtOutput.BackColor = System.Drawing.Color.Black;
            this.txtOutput.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtOutput.Location = new System.Drawing.Point(490, 437);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(282, 73);
            this.txtOutput.TabIndex = 32;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Location = new System.Drawing.Point(697, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 52);
            this.btnExit.TabIndex = 33;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 522);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.txtPoint);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtDie2);
            this.Controls.Add(this.txtDie1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblPoint);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblDie2);
            this.Controls.Add(this.lblDie1);
            this.Controls.Add(this.lblStats);
            this.Controls.Add(this.txtStats);
            this.Controls.Add(this.picBPuck);
            this.Controls.Add(this.picWPuck10);
            this.Controls.Add(this.picWPuck8);
            this.Controls.Add(this.picWPuck6);
            this.Controls.Add(this.picWPuck5);
            this.Controls.Add(this.picWPuck4);
            this.Controls.Add(this.picWPuck9);
            this.Controls.Add(this.pic26);
            this.Controls.Add(this.pic25);
            this.Controls.Add(this.pic24);
            this.Controls.Add(this.pic23);
            this.Controls.Add(this.pic22);
            this.Controls.Add(this.pic16);
            this.Controls.Add(this.pic15);
            this.Controls.Add(this.pic14);
            this.Controls.Add(this.pic13);
            this.Controls.Add(this.pic21);
            this.Controls.Add(this.pic12);
            this.Controls.Add(this.pic11);
            this.Controls.Add(this.btnRoll);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pic11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWPuck10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBPuck)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.PictureBox pic11;
        private System.Windows.Forms.PictureBox pic12;
        private System.Windows.Forms.PictureBox pic21;
        private System.Windows.Forms.PictureBox pic13;
        private System.Windows.Forms.PictureBox pic14;
        private System.Windows.Forms.PictureBox pic15;
        private System.Windows.Forms.PictureBox pic16;
        private System.Windows.Forms.PictureBox pic22;
        private System.Windows.Forms.PictureBox pic23;
        private System.Windows.Forms.PictureBox pic24;
        private System.Windows.Forms.PictureBox pic25;
        private System.Windows.Forms.PictureBox pic26;
        private System.Windows.Forms.PictureBox picWPuck9;
        private System.Windows.Forms.PictureBox picWPuck4;
        private System.Windows.Forms.PictureBox picWPuck5;
        private System.Windows.Forms.PictureBox picWPuck6;
        private System.Windows.Forms.PictureBox picWPuck8;
        private System.Windows.Forms.PictureBox picWPuck10;
        private System.Windows.Forms.PictureBox picBPuck;
        private System.Windows.Forms.TextBox txtStats;
        private System.Windows.Forms.Label lblStats;
        private System.Windows.Forms.Label lblDie1;
        private System.Windows.Forms.Label lblDie2;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblPoint;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox txtDie1;
        private System.Windows.Forms.TextBox txtDie2;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtPoint;
        private System.Windows.Forms.TextBox txtScore;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Button btnExit;
    }
}

