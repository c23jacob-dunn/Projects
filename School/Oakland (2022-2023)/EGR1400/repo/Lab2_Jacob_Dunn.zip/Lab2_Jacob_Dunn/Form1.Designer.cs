﻿namespace Lab2_Jacob_Dunn
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBoxScores1 = new System.Windows.Forms.GroupBox();
            this.grpBoxScores2 = new System.Windows.Forms.GroupBox();
            this.lblTestScore1 = new System.Windows.Forms.Label();
            this.lblTestScore2 = new System.Windows.Forms.Label();
            this.lblTestScore3 = new System.Windows.Forms.Label();
            this.lblTestScore4 = new System.Windows.Forms.Label();
            this.lblTestScore5 = new System.Windows.Forms.Label();
            this.lblTestScore6 = new System.Windows.Forms.Label();
            this.lblTestScore7 = new System.Windows.Forms.Label();
            this.lblTestScore8 = new System.Windows.Forms.Label();
            this.lblTestScore9 = new System.Windows.Forms.Label();
            this.lblTestScore10 = new System.Windows.Forms.Label();
            this.btnRandom = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.btnComputeStats = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblMean = new System.Windows.Forms.Label();
            this.lblStdDev = new System.Windows.Forms.Label();
            this.txtMean = new System.Windows.Forms.TextBox();
            this.txtStdDev = new System.Windows.Forms.TextBox();
            this.grpBoxScores1.SuspendLayout();
            this.grpBoxScores2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxScores1
            // 
            this.grpBoxScores1.Controls.Add(this.textBox5);
            this.grpBoxScores1.Controls.Add(this.textBox4);
            this.grpBoxScores1.Controls.Add(this.textBox3);
            this.grpBoxScores1.Controls.Add(this.textBox2);
            this.grpBoxScores1.Controls.Add(this.lblTestScore4);
            this.grpBoxScores1.Controls.Add(this.textBox1);
            this.grpBoxScores1.Controls.Add(this.lblTestScore5);
            this.grpBoxScores1.Controls.Add(this.lblTestScore3);
            this.grpBoxScores1.Controls.Add(this.lblTestScore2);
            this.grpBoxScores1.Controls.Add(this.lblTestScore1);
            this.grpBoxScores1.Location = new System.Drawing.Point(124, 26);
            this.grpBoxScores1.Name = "grpBoxScores1";
            this.grpBoxScores1.Size = new System.Drawing.Size(252, 200);
            this.grpBoxScores1.TabIndex = 0;
            this.grpBoxScores1.TabStop = false;
            this.grpBoxScores1.Text = "Test Scores 50-100";
            // 
            // grpBoxScores2
            // 
            this.grpBoxScores2.Controls.Add(this.textBox10);
            this.grpBoxScores2.Controls.Add(this.textBox9);
            this.grpBoxScores2.Controls.Add(this.textBox8);
            this.grpBoxScores2.Controls.Add(this.textBox7);
            this.grpBoxScores2.Controls.Add(this.textBox6);
            this.grpBoxScores2.Controls.Add(this.lblTestScore10);
            this.grpBoxScores2.Controls.Add(this.lblTestScore9);
            this.grpBoxScores2.Controls.Add(this.lblTestScore8);
            this.grpBoxScores2.Controls.Add(this.lblTestScore7);
            this.grpBoxScores2.Controls.Add(this.lblTestScore6);
            this.grpBoxScores2.Location = new System.Drawing.Point(430, 26);
            this.grpBoxScores2.Name = "grpBoxScores2";
            this.grpBoxScores2.Size = new System.Drawing.Size(256, 200);
            this.grpBoxScores2.TabIndex = 1;
            this.grpBoxScores2.TabStop = false;
            this.grpBoxScores2.Text = "Test Scores 30-100";
            // 
            // lblTestScore1
            // 
            this.lblTestScore1.AutoSize = true;
            this.lblTestScore1.Location = new System.Drawing.Point(6, 36);
            this.lblTestScore1.Name = "lblTestScore1";
            this.lblTestScore1.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore1.TabIndex = 0;
            this.lblTestScore1.Text = "Test Score 1:";
            // 
            // lblTestScore2
            // 
            this.lblTestScore2.AutoSize = true;
            this.lblTestScore2.Location = new System.Drawing.Point(6, 66);
            this.lblTestScore2.Name = "lblTestScore2";
            this.lblTestScore2.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore2.TabIndex = 1;
            this.lblTestScore2.Text = "Test Score 2:";
            // 
            // lblTestScore3
            // 
            this.lblTestScore3.AutoSize = true;
            this.lblTestScore3.Location = new System.Drawing.Point(6, 102);
            this.lblTestScore3.Name = "lblTestScore3";
            this.lblTestScore3.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore3.TabIndex = 2;
            this.lblTestScore3.Text = "Test Score 3:";
            // 
            // lblTestScore4
            // 
            this.lblTestScore4.AutoSize = true;
            this.lblTestScore4.Location = new System.Drawing.Point(6, 136);
            this.lblTestScore4.Name = "lblTestScore4";
            this.lblTestScore4.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore4.TabIndex = 3;
            this.lblTestScore4.Text = "Test Score 4:";
            // 
            // lblTestScore5
            // 
            this.lblTestScore5.AutoSize = true;
            this.lblTestScore5.Location = new System.Drawing.Point(6, 167);
            this.lblTestScore5.Name = "lblTestScore5";
            this.lblTestScore5.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore5.TabIndex = 3;
            this.lblTestScore5.Text = "Test Score 5:";
            // 
            // lblTestScore6
            // 
            this.lblTestScore6.AutoSize = true;
            this.lblTestScore6.Location = new System.Drawing.Point(6, 36);
            this.lblTestScore6.Name = "lblTestScore6";
            this.lblTestScore6.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore6.TabIndex = 0;
            this.lblTestScore6.Text = "Test Score 6:";
            // 
            // lblTestScore7
            // 
            this.lblTestScore7.AutoSize = true;
            this.lblTestScore7.Location = new System.Drawing.Point(6, 66);
            this.lblTestScore7.Name = "lblTestScore7";
            this.lblTestScore7.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore7.TabIndex = 1;
            this.lblTestScore7.Text = "Test Score 7:";
            // 
            // lblTestScore8
            // 
            this.lblTestScore8.AutoSize = true;
            this.lblTestScore8.Location = new System.Drawing.Point(6, 102);
            this.lblTestScore8.Name = "lblTestScore8";
            this.lblTestScore8.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore8.TabIndex = 2;
            this.lblTestScore8.Text = "Test Score 8:";
            // 
            // lblTestScore9
            // 
            this.lblTestScore9.AutoSize = true;
            this.lblTestScore9.Location = new System.Drawing.Point(6, 136);
            this.lblTestScore9.Name = "lblTestScore9";
            this.lblTestScore9.Size = new System.Drawing.Size(103, 20);
            this.lblTestScore9.TabIndex = 3;
            this.lblTestScore9.Text = "Test Score 9:";
            // 
            // lblTestScore10
            // 
            this.lblTestScore10.AutoSize = true;
            this.lblTestScore10.Location = new System.Drawing.Point(6, 167);
            this.lblTestScore10.Name = "lblTestScore10";
            this.lblTestScore10.Size = new System.Drawing.Size(112, 20);
            this.lblTestScore10.TabIndex = 4;
            this.lblTestScore10.Text = "Test Score 10:";
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(274, 232);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(265, 53);
            this.btnRandom.TabIndex = 4;
            this.btnRandom.Text = "Fill Random Test Scores";
            this.btnRandom.UseVisualStyleBackColor = true;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(133, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(133, 66);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(133, 99);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(100, 26);
            this.textBox3.TabIndex = 6;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(133, 136);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(100, 26);
            this.textBox4.TabIndex = 7;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(133, 168);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(100, 26);
            this.textBox5.TabIndex = 8;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(131, 33);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(100, 26);
            this.textBox6.TabIndex = 5;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(131, 68);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(100, 26);
            this.textBox7.TabIndex = 6;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(131, 100);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(100, 26);
            this.textBox8.TabIndex = 7;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(131, 133);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(100, 26);
            this.textBox9.TabIndex = 8;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(131, 165);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(100, 26);
            this.textBox10.TabIndex = 9;
            // 
            // btnComputeStats
            // 
            this.btnComputeStats.Location = new System.Drawing.Point(210, 372);
            this.btnComputeStats.Name = "btnComputeStats";
            this.btnComputeStats.Size = new System.Drawing.Size(96, 66);
            this.btnComputeStats.TabIndex = 5;
            this.btnComputeStats.Text = "Compute Stats";
            this.btnComputeStats.UseVisualStyleBackColor = true;
            this.btnComputeStats.Click += new System.EventHandler(this.btnComputeStats_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(312, 372);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(178, 66);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear Test Scores and Stats";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(496, 372);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(96, 66);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblMean
            // 
            this.lblMean.AutoSize = true;
            this.lblMean.Location = new System.Drawing.Point(323, 298);
            this.lblMean.Name = "lblMean";
            this.lblMean.Size = new System.Drawing.Size(53, 20);
            this.lblMean.TabIndex = 8;
            this.lblMean.Text = "Mean:";
            // 
            // lblStdDev
            // 
            this.lblStdDev.AutoSize = true;
            this.lblStdDev.Location = new System.Drawing.Point(227, 334);
            this.lblStdDev.Name = "lblStdDev";
            this.lblStdDev.Size = new System.Drawing.Size(149, 20);
            this.lblStdDev.TabIndex = 9;
            this.lblStdDev.Text = "Standard Deviation:";
            // 
            // txtMean
            // 
            this.txtMean.Location = new System.Drawing.Point(390, 295);
            this.txtMean.Name = "txtMean";
            this.txtMean.ReadOnly = true;
            this.txtMean.Size = new System.Drawing.Size(100, 26);
            this.txtMean.TabIndex = 10;
            // 
            // txtStdDev
            // 
            this.txtStdDev.Location = new System.Drawing.Point(390, 331);
            this.txtStdDev.Name = "txtStdDev";
            this.txtStdDev.ReadOnly = true;
            this.txtStdDev.Size = new System.Drawing.Size(100, 26);
            this.txtStdDev.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 476);
            this.Controls.Add(this.txtStdDev);
            this.Controls.Add(this.txtMean);
            this.Controls.Add(this.lblStdDev);
            this.Controls.Add(this.lblMean);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnComputeStats);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.grpBoxScores2);
            this.Controls.Add(this.grpBoxScores1);
            this.Name = "Form1";
            this.Text = "EGR 1400 LAB 2 STATISTICS";
            this.grpBoxScores1.ResumeLayout(false);
            this.grpBoxScores1.PerformLayout();
            this.grpBoxScores2.ResumeLayout(false);
            this.grpBoxScores2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxScores1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblTestScore5;
        private System.Windows.Forms.Label lblTestScore3;
        private System.Windows.Forms.Label lblTestScore2;
        private System.Windows.Forms.Label lblTestScore1;
        private System.Windows.Forms.GroupBox grpBoxScores2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label lblTestScore10;
        private System.Windows.Forms.Label lblTestScore9;
        private System.Windows.Forms.Label lblTestScore8;
        private System.Windows.Forms.Label lblTestScore7;
        private System.Windows.Forms.Label lblTestScore6;
        private System.Windows.Forms.Label lblTestScore4;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Button btnComputeStats;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblMean;
        private System.Windows.Forms.Label lblStdDev;
        private System.Windows.Forms.TextBox txtMean;
        private System.Windows.Forms.TextBox txtStdDev;
    }
}

